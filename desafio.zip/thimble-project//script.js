function bien() {

  const campo = document.getElementById("frase").value;
  const campoDos = campo.trim().toLocaleLowerCase();
  
if (campoDos == "confia en ti mismo" || campoDos == "confía en ti mismo") {  
  
  
  
  Swal.fire({
    title: 'Felicitaciones!',
    text: 'Completaste el desafio!',
    imageUrl: 'diploma.png',
    imageWidth: 300,
    imageHeight: 200,
  })

}
  
  else {
    
    
  }

}